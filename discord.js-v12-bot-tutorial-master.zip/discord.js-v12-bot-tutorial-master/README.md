# Discord.JS V12 Source Code
You guys requested it, so I listened. Here's the source code seen in my Discord.JS V12 Bot Tutorial Videos

<br>
<img height="500" src="https://cdn.discordapp.com/attachments/711326145106149456/711326259052806164/Bot_Tutorials_Logo.PNG"
<br>
